package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Exception.BusinessException;
import com.example.Repository.AccountRepository;
import com.example.model.AccountModel;
import com.example.model.UserModel;

@Service
public class AccountService {

	@Autowired
	AccountRepository accRepo;
	
	public List<AccountModel> viewById(String yes, int cid) {
		
		List<AccountModel> acclist = null;
		try {
		 acclist = accRepo.viewUserById(yes, cid);
			}catch(Exception e) {
				throw new BusinessException("611","Something is went wrong in service layer while fetching all Accounts"+ e.getMessage());
			}if (acclist.isEmpty())
				throw new BusinessException("610","List is empty");
			return acclist;
		
	}

	public void addAccount(AccountModel acc) {
		
		 accRepo.save(acc);
		
	}

	public void softDeleteUser(int cid, int accno) {
		
		String no="No";
		accRepo.softDelete(cid,accno,no);
		
	}

}
