package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Exception.BusinessException;
import com.example.Repository.UserRepository;
import com.example.model.UserModel;

@Service
public class UserService {

	@Autowired
	UserRepository userRepo;

	public void saveUser(UserModel employee) {

		userRepo.save(employee);

	}

	public Optional<UserModel> getById(int id) {

		System.out.println("into");
		return userRepo.findByUsername(id);

	}

	public void softDeleteUser(String uid)
	{
			String no="No";
			userRepo.softdelete(no,uid);
	}

	public void updateEmployee(UserModel employee)

	{
		userRepo.save(employee);

	}

	public List<UserModel> viewAll(String yes) {
		List<UserModel> userlist = null;
		try {
			userlist = userRepo.findAllById(yes);
		}catch(Exception e) {
			throw new BusinessException("601","Something is went wrong in service layer while fetching all users"+ e.getMessage());
		}
		if (userlist.isEmpty())
			throw new BusinessException("600","List is completely empty");
		return userlist;
		
	}
	public List<UserModel> viewById(String yes, int id) {
		List<UserModel> userlist = null;
		try {
		 userlist = userRepo.viewUserById(yes, id);
		}catch(Exception e) {
			throw new BusinessException("603","Something is went wrong in service layer while fetching all users"+ e.getMessage());
		}if (userlist.isEmpty())
			throw new BusinessException("602","List is empty");
		return userlist;
	}
	
	public UserModel getUserById(String id) {

		return userRepo.getById(id);

	}
}
